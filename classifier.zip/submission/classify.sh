#!/bin/bash
python3 src/classify.py $1 $2