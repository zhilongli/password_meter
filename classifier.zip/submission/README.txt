The classifier runs with Python3, below are the instructions for getting it running.
1. To install the dependencies and data, the setup.sh script must be run. In a terminal within the extracted folder, first make the bash script executable by running `chmod +x setup.sh`, then run the script with `./setup.sh`
2. Then make the classify.sh script executable by `chmod +x classify.sh`
3. Now the classifier will run with the commands specified in the instructions: `./classify.sh ~/inputs/passwords.txt ~/outputs/classified_passwords.txt`
