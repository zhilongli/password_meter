import pickle as pkl
import random

with open('models/trained_ngram_10000000.pkl', 'rb') as f:
    full_ngram = pkl.load(f)
with open('models/pcfg_emissions.pkl', 'rb') as f:
    full_emis = pkl.load(f)

half_ngram = dict(random.sample(full_ngram.items(), len(full_ngram)//2))
half_emis = dict(random.sample(full_emis.items(), len(full_emis)//2))
print(half_emis)

with open('half_ngram.pkl', 'wb+') as f:
    pkl.dump(half_ngram, f)

with open('half_emis.pkl', 'wb+') as f:
    pkl.dump(half_emis, f)