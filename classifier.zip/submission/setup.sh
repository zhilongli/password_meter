#!/bin/bash
pip3 install numpy
wget https://github.com/zhilongli/password_meter/raw/master/models/trained_ngram_10000000_small.pklz
wget https://github.com/zhilongli/password_meter/raw/master/models/pcfg_small.pklz
mv trained_ngram_10000000_small.pklz models/
mv pcfg_small.pklz models/
